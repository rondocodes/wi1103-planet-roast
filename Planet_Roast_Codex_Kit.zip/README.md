# Planet Roast: Midterm Meltdown

Save the planet. Survive the syllabus.

Recommended GitHub repository: **wi1103-planet-roast**

This is the planning and content kit for a funny English WI1103 sustainability study game. It is not the implemented app.

## Start here

1. Upload this folder's contents into your new repo root.
2. Open the repo in Codex.
3. Read CODEX_PROMPTS.md and paste Prompt 0, then Prompt 1.
4. Use the audit, polish, and bug-fix prompts only when useful.
5. Use the separate publication prompt when you want to publish.

## Included

| File | Purpose |
| --- | --- |
| PRD.md | Product behavior, game design, exact scoring, accessibility, persistence, acceptance criteria |
| CODEX_PROMPTS.md | Repo setup plus inspect/build/audit/polish/fix/publish prompts |
| CONTENT_REVIEW.md | Provisional study key, source gaps, ambiguity policy, correction notes |
| content/questions.seed.json | 36 English study adaptations with options, explanations, hints, hooks, IDs, source pages |
| content/references.json | Primary-source concept checks and official deployment reference |

The source includes Q1–7 and Q18–46; Q8–17 are absent. There is no official answer key. The seed has 32 provisional gradable items and four blocked review cards (Q5, Q6, Q7, Q33). Do not hide these limitations or fill the gap with invented past-paper questions.

Roasts are local authored jokes with Off/Mild/Spicy settings. They target wrong answers and fictional situations, without identity slurs or personal-worth attacks.

The original PDF is not included. Keep any optional copy in ignored private-source/. A publicly hosted client app exposes its bundled study bank. No repo or website has been created by this kit.
